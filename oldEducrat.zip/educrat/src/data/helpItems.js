export const helpItems = [
  {
    id: 1,
    icon: "/assets/img/help-center/1.svg",
    title: "Getting Started",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    id: 2,
    icon: "/assets/img/help-center/2.svg",
    title: "Account / Profile",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    id: 3,
    icon: "/assets/img/help-center/3.svg",
    title: "Troubleshooting",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    id: 4,
    icon: "/assets/img/help-center/4.svg",
    title: "Purchase / Refunds",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    id: 5,
    icon: "/assets/img/help-center/5.svg",
    title: "Course Taking",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
  {
    id: 6,
    icon: "/assets/img/help-center/6.svg",
    title: "Mobile General",
    description: "Lorem ipsum is placeholder text commonly used in site.",
  },
];

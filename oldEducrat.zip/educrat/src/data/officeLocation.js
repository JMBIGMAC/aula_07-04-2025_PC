export const locationData = [
  {
    id: 1,
    location: "London",
    address: "328 Queensberry Street, North Melbourne VIC 3051, Australia.",
    phoneNumber: "+(1) 123 456 7890",
    email: "hi@educrat.com",
  },
  {
    id: 2,
    location: "Paris",
    address: "328 Queensberry Street, North Melbourne VIC 3051, Australia.",
    phoneNumber: "+(1) 123 456 7890",
    email: "hi@educrat.com",
  },
  {
    id: 3,
    location: "Los Angeles",
    address: "328 Queensberry Street, North Melbourne VIC 3051, Australia.",
    phoneNumber: "+(1) 123 456 7890",
    email: "hi@educrat.com",
  },
];

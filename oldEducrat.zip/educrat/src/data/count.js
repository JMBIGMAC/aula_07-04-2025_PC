export const counters = [
  {
    id: 1,
    number: "350,000+",
    title: "Students worldwide",
  },
  {
    id: 2,
    number: "496,000+",
    title: "Total course views",
  },
  {
    id: 3,
    number: "19,000+",
    title: "Five-star course reviews",
  },
  {
    id: 4,
    number: "987,000+",
    title: "Students community",
  },
];

export const brands = [
  "/assets/img/clients/1.svg",
  "/assets/img/clients/2.svg",
  "/assets/img/clients/3.svg",
  "/assets/img/clients/4.svg",
  "/assets/img/clients/5.svg",
  "/assets/img/clients/6.svg",
];

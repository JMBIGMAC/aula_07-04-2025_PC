mudanças:
tradução do arquivo "data"
modificações necessarias para manter os arquivos:
    Home 1
    About
    Contact US
    Courses List V4
    Course V6
    Course Cart
    Course Checkout
    Lesson Page 2
    Blog 3
    Blog Single
    Dashboard Completo
    Eventos 2
    Event Cart
    Event Checkout
correção de dependencias.
import React from "react";

export default function Wrapper({ children }) {
  return <>{children}</>;
}

export const helpItems = [
  {
    id: 1,
    icon: "/assets/img/help-center/1.svg",
    title: "Introdução",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
  {
    id: 2,
    icon: "/assets/img/help-center/2.svg",
    title: "Conta / Perfil",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
  {
    id: 3,
    icon: "/assets/img/help-center/3.svg",
    title: "Solução de Problemas",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
  {
    id: 4,
    icon: "/assets/img/help-center/4.svg",
    title: "Compra / Reembolsos",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
  {
    id: 5,
    icon: "/assets/img/help-center/5.svg",
    title: "Realização de Cursos",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
  {
    id: 6,
    icon: "/assets/img/help-center/6.svg",
    title: "Geral Mobile",
    description: "Lorem ipsum é um texto fictício comumente usado em sites.",
  },
];

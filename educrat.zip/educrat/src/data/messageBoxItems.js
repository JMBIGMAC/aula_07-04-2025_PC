export const infoItems = [
  {
    id: 1,
    bgClass: "bg-info-1",
    textClass: "text-info-2",
    icon: "x",
    message: "Informação: Ação pendente do usuário",
  },
  {
    id: 2,
    bgClass: "bg-warning-1",
    textClass: "text-warning-2",
    icon: "x",
    message: "Informação: Ação pendente do usuário",
  },
  {
    id: 3,
    bgClass: "bg-error-1",
    textClass: "text-error-2",
    icon: "x",
    message: "Informação: Ação pendente do usuário",
  },
  {
    id: 4,
    bgClass: "bg-success-1",
    textClass: "text-success-2",
    icon: "x",
    message: "Informação: Ação pendente do usuário",
  },
];

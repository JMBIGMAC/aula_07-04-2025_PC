export const links = [
  { id: 1, href: "/help-center", label: "ajuda" },
  { id: 2, href: "/terms", label: "politica de privacidade" },
  { id: 3, href: "/terms", label: "Cookie noticia" },
  { id: 4, href: "/terms", label: "segurança" },
  { id: 5, href: "/terms", label: "termos de uso" },
];

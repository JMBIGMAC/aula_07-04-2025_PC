export const socialMediaLinks = [
  { id: 1, href: "#", iconClassName: "icon-facebook" },
  { id: 2, href: "#", iconClassName: "icon-twitter" },
  { id: 3, href: "#", iconClassName: "icon-instagram" },
  { id: 4, href: "#", iconClassName: "icon-linkedin" },
];

//   iconClassName are from font awesome

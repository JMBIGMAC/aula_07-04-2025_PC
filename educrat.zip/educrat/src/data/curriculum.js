export const curriculum = [
  {
    id: 1,
    title: "Introduction to JavaScript",
    items: [
      { id: 1, title: "Introduction" },
      { id: 2, title: "Installing Development Software" },
      { id: 3, title: "Hello World Project from GitHub" },
    ],
  },
  {
    id: 2,
    title: "Introduction to JavaScript",
    items: [
      { id: 1, title: "Introduction" },
      { id: 2, title: "Installing Development Software" },
      { id: 3, title: "Hello World Project from GitHub" },
    ],
  },
  // Add more sections as needed
];

export const schoolAchievement = [
  {
    id: 1,
    imageSrc: "/assets/img/home-3/achieve/1.svg",
    title: "350,000+",
    text: "Students worldwide",
  },
  {
    id: 2,
    imageSrc: "/assets/img/home-3/achieve/2.svg",
    title: "496,000+",
    text: "Total course views",
  },
  {
    id: 3,
    imageSrc: "/assets/img/home-3/achieve/3.svg",
    title: "19,000+",
    text: "Five-star course reviews",
  },
  {
    id: 4,
    imageSrc: "/assets/img/home-3/achieve/4.svg",
    title: "987,000+",
    text: "Students community",
  },
];

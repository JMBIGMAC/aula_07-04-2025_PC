export const counters = [
  {
    id: 1,
    number: "350.000+",
    title: "Estudantes no mundo todo",
  },
  {
    id: 2,
    number: "496.000+",
    title: "Visualizações totais de cursos",
  },
  {
    id: 3,
    number: "19.000+",
    title: "Avaliações de cursos com cinco estrelas",
  },
  {
    id: 4,
    number: "987.000+",
    title: "Comunidade de estudantes",
  },
];
